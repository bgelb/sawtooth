/*
 * $projectname$.cpp
 *
 * Created: $date$
 * Author : $user$
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

